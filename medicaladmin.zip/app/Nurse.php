<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Nurse extends Model
{
	protected $table = 'nurses';
}
