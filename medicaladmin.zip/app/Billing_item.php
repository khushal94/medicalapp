<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Billing_item extends Model
{
	protected $table = 'billing_items';
}
