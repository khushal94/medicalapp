<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LabBooking extends Model
{
    protected $table = 'labbooking';

}
